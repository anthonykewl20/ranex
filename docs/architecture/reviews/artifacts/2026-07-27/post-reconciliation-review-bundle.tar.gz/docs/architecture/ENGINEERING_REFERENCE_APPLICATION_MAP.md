# Ranex Engineering Reference Application Map

| Field | Value |
|---|---|
| Document ID | `MAP-ENG-REF-001` |
| Version | `1.0.0` |
| Status | `CONDITIONALLY_ACCEPTED` normative supporting map; runtime practice remains unvalidated |
| Date | 2026-07-27 |
| Owner and decision authority | Human governor |
| Scope | How the saved software-engineering books and SWEBOK materially shape the complete Ranex lifecycle, architecture, file structure, construction, verification, operation, and improvement system |
| Parent policy | [Ranex Core SDLC Operating Model](./CORE_SDLC_OPERATING_MODEL.md) |
| Parent architecture | [Hermes-to-Ranex Ground-Zero Full-System Architecture](./HERMES_GROUND_ZERO_FULL_SYSTEM_ARCHITECTURE.md) |
| Control catalog | [Ranex SDLC Control Catalog](./SDLC_CONTROL_CATALOG.md) |
| Exact corpus | [Foundational-reference corpus manifest](./reviews/artifacts/2026-07-27/foundational-reference-corpus-manifest.sha256) |
| Corpus count/size | 12 files / 47,732,875 bytes; six PDF/Markdown pairs |
| Manifest SHA-256 | `e9bb449238bd0c8c326588cb7e6df2d82beb3796c09ced2d5b5b1da409326472` |
| Authority rule | Standards and the owner-accepted SDLC govern; books are major engineering references; AI research governs neither lifecycle nor product authority |
| Rights class | `CURATED_RESEARCH`, `NOASSERTION`; local possession does not establish redistribution rights |
| Review trigger | A reference is added/replaced, a mapped rule changes, a contradiction is found, or runtime evidence falsifies an adopted practice |

> **The books are major references, not decoration.**
>
> They are used to close underspecified engineering work. They do not replace
> the established human software-development lifecycle, become executable
> authority, or turn one author's heuristic into a universal gate.

## 1. Governing hierarchy

Ranex applies evidence in this order:

1. **Human owner decisions and accepted ADRs** define internal product direction,
   decision rights, risk acceptance, and explicit inclusions/exclusions.
   They cannot waive applicable law, contract, license, privacy, third-party
   rights, or mandatory external obligations.
2. **Established lifecycle and engineering sources**—principally
   ISO/IEC/IEEE 12207:2026, SWEBOK, ISO/IEC 29110, NASA engineering guidance, and
   NIST SSDF—define the complete discipline coverage and control frame.
3. **The saved books are major practice references.** They deepen how design,
   construction, testing, collaboration, estimation, operation, and evolution
   are performed inside that frame.
4. **Hermes/upstream evidence** defines inherited behavior, compatibility,
   migration, provenance, and upstream-sync facts.
5. **AI-agent research** informs how probabilistic workers are bounded,
   measured, and verified. It cannot define the SDLC or transfer human
   authority.
6. **Runtime Ranex evidence** calibrates or falsifies a selected practice.

When sources disagree, Ranex does not average them. The owning role records the
conflict, applies the higher authority, tests material uncertainty, and records
the resolution in an RFC/ADR or process-assurance decision.

SWEBOK V4.0a was released before ISO/IEC/IEEE 12207:2026 and maps its knowledge
areas to the then-current 2017 edition. That internal crosswalk is historical;
Ranex must verify and version a 2026 mapping before claiming clause coverage.

## 2. Exact major-reference corpus

The current reference set has six conceptual works, each represented by a PDF
and a lossy Markdown extraction. A PDF/Markdown pair is one intellectual work,
not two independent sources.

| Major reference | Primary Ranex use | Binding limitation |
|---|---|---|
| [SWEBOK Guide V4.0a](https://www.computer.org/education/bodies-of-knowledge/software-engineering/v4) | Consensus knowledge-area map and broad discipline-coverage check across requirements, architecture, design, construction, testing, operations, maintenance, configuration, management, process, quality, security, economics, and foundations | Non-comprehensive knowledge map, not a prescriptive Ranex lifecycle or conformity claim; 12207:2026 and other sources supply process coverage it does not directly map |
| [Code Complete, Second Edition — retained Chapter 5 excerpt](https://www.microsoftpressstore.com/articles/article.aspx?p=2222451) | Design during construction, complexity management, information hiding, coupling/cohesion, contracts, testability, binding time, iterative and proportionate design | The local PDF is a 120-page excerpt; only retained Chapter 5 is evidence, not the absent book chapters |
| [Clean Code](https://www.informit.com/store/clean-code-a-handbook-of-agile-software-craftsmanship-9780132350884) | Local construction discipline, boundary wrapping, startup/runtime separation, testability, expressive intent, small verified refactoring, concurrency cautions | Opinionated 2009 Java/TDD-era heuristics; code is not the sole authority in Ranex |
| [The Pragmatic Programmer, original first edition](https://www.informit.com/store/pragmatic-programmer-from-journeyman-to-master-9780201616224) | Responsibility, orthogonality, reversibility, contracts, tracer routes, plain-text/source-control discipline, automation, debugging, testing, and regression learning | Original 2000 text / local 25th printing from 2010; contextual guidance whose tracer work cannot shrink the full map or bypass gates |
| [System Design Interview: An Insider's Guide, Second Edition](https://openlibrary.org/works/OL21947791W/System_Design_Interview_-_an_Insider%27s_Guide) | Scope clarification, high-level decomposition, deep-dive selection, trade-off communication, back-of-envelope checks, failure/monitoring prompts, and a pattern catalogue | 2020 interview-preparation source with simplified web-scale patterns; not Ranex's reference architecture |
| [The Clean Coder](https://www.informit.com/store/clean-coder-a-code-of-conduct-for-professional-programmers-9780137081073) | Professional responsibility, explicit commitments, early risk/lateness disclosure, acceptance criteria, layered test strategy, sustainable work, collaboration, estimation, mentoring, and stable teams | One author's 2011 practice position; fixed coverage, TDD, staffing, time, or test-percentage rules are not universal Ranex mandates |

All six references are **major** because each owns a named part of the
application map below. “Major” does not mean equal authority, current in every
technical detail, scientifically proven, or safe to redistribute.

### 2.1 Rights and public-repository blocker

The repository manifest says the target repository is public. The PDFs and
full/near-full Markdown derivatives carry restrictive or all-rights-reserved
notices; the local Pragmatic Programmer copy is visibly personalized for a
named third party. `CURATED_RESEARCH` and `NOASSERTION` classify uncertainty;
they do not create a license.

Accordingly:

- the twelve full-text artifacts are `LOCAL_ONLY`;
- public-repository inclusion and release are
  `PROHIBITED_PENDING_RIGHTS`;
- they remain untracked or in access-controlled artifact storage unless a
  documented right-to-distribute decision says otherwise;
- a public Ranex deliverable may retain lawful bibliographic references,
  original paraphrases, claim-level notes, and non-reconstructive digests; and
- no human ADR or model review can waive copyright, contract, privacy, or
  third-party rights.

The repository enforces this separation by ignoring
`docs/research/books/`, classifying every local source path in the licensing
manifest, and requiring the release gate to reject any `LOCAL_ONLY` path found
in the Git index, release archive, package, mirror, or deployment input. The
public-safe map links lawful publisher/bibliographic pages and the
non-reconstructive digest manifest, never a required local full-text path.

This publication blocker does not demote the books as major design references.
It separates the right to consult a source from the right to redistribute it.

## 3. How an unclear area is closed

No developer or AI worker resolves architectural fog by improvising code. The
required ambiguity-closure protocol is:

```text
name the unclear decision and accountable owner
  -> bind current requirements, quality attributes, constraints, and exact subject
  -> locate applicable lifecycle/control obligations
  -> consult every relevant major reference
  -> identify facts, heuristics, conflicts, dated assumptions, and unknowns
  -> produce at least one viable alternative plus status quo
  -> map each alternative to owner, state, data, effect, API, file, failure, and recovery
  -> predeclare falsification and acceptance evidence
  -> obtain the required independent challenge and human decision
  -> implement a bounded route through the already-complete map
  -> retain operational/outcome evidence and revise through normal change control
```

An uncertainty may end in:

- an accepted architecture decision;
- a constrained implementation experiment;
- an explicitly inactive attachment point;
- an explicit product exclusion;
- a blocked item with named closure evidence; or
- rejection of the proposed capability.

“We will decide while coding” is acceptable only for a named local design
choice whose allowed boundary, invariants, evidence, and escalation condition
are already fixed. It is not acceptable for authority, state ownership,
security, data lifecycle, public API, compatibility, release, or recovery.

## 4. Full lifecycle application

| Core stage | Major-reference contribution | Required Ranex result |
|---|---|---|
| `GOVERN` | SWEBOK professional practice, process, quality, management, and economics; Clean Coder responsibility/commitments | Named decision rights, policy, capability ownership, conformance, competence, and improvement system |
| `SHAPE` | Pragmatic responsibility/value communication; Clean Coder explicit commitments; System Design scope questions | Owned need, user outcome, boundaries, non-goals, work class, and initial risk |
| `DISCOVER` | Pragmatic requirements exploration and reversibility; System Design clarification and estimation prompts | Current behavior, user/actor evidence, assumptions, unknowns, falsifiable hypothesis, and scale envelope |
| `SPECIFY` | SWEBOK requirements; Pragmatic contracts; Clean Coder executable acceptance examples | Functional and quality requirements, misuse/failure cases, acceptance criteria, trace links, and change rules |
| `DESIGN` | SWEBOK architecture/design; Code Complete complexity and information hiding; Clean Code boundaries; System Design decomposition/deep dive | Full owner/boundary/API/state/data/effect/file/failure/recovery map plus alternatives and ADR |
| `PLAN` | SWEBOK engineering management/economics; Clean Coder estimation-versus-commitment; Pragmatic reversible increments | Forecast range, dependencies, capacity, vertical routes, verification/release/rollback plan, and recommitment triggers |
| `BUILD` | Code Complete construction design; Clean Code intent/testability/refactoring; Pragmatic contracts/automation | Dependency-conforming code, tests, docs, generated contracts, immutable run evidence, and no hidden scope |
| `VERIFY` | SWEBOK testing/quality; Clean Coder layered testing/acceptance; Pragmatic regression learning; Clean Code boundary tests | Exact-subject independent evidence, deterministic gates, failure-path proof, no self-approval |
| `RELEASE` | SWEBOK configuration/operations; Pragmatic automation/reversibility; System Design monitoring/failure prompts | Immutable artifact, SBOM/provenance, migration, progressive exposure, health stop, rollback, and permit |
| `OPERATE` | SWEBOK operations/maintenance; Pragmatic observability/debugging; System Design capacity/failure catalogue | Service ownership, SLI/SLO, telemetry, support, incident, reconciliation, backup/restore, and capacity evidence |
| `MAINTAIN_OR_RETIRE` | SWEBOK maintenance/configuration; Code Complete maintainability; Pragmatic reversibility | Controlled change or removal, consumer/data/access migration, compatibility evidence, and retained history |
| `IMPROVE` | SWEBOK process/measurement; Clean Coder learning/mentoring; Pragmatic continuous learning | Evidence-bound capability assessment, bounded experiment, guardrails, corrective action, and human decision |

The table is one continuous, iterative system. It is not a queue of
book-defined departments.

## 5. Architecture decision workflow

Every material architecture question uses the following full workflow.

### 5.1 Frame the real problem

The owner records:

- actors and user/service outcome;
- present behavior and evidence;
- functional requirements;
- security, privacy, reliability, performance, accessibility, operability,
  maintainability, portability, provenance, compatibility, and cost
  attributes;
- expected load and uncertainty instead of unearned internet-scale assumptions;
- external systems and effects;
- retained Hermes behavior and upstream baseline;
- reversibility, recovery, and retirement needs; and
- explicit non-goals.

System Design Interview's clarification method is useful here. Its web-scale
defaults are not. Ranex remains a one-host modular monolith unless measured
requirements and an accepted product-scope ADR change that decision.

### 5.2 Produce a high-level decomposition

The design names:

- bounded contexts and one accountable owner for every state/effect;
- system and trust boundaries;
- user/operator/worker/external actors;
- public commands, queries, events, and views;
- synchronous and asynchronous interaction;
- canonical records versus projections;
- storage and transaction ownership;
- failure domains and isolation;
- deployment/runtime topology; and
- final repository homes.

This is the complete map. No implementation itinerary is allowed to determine
its extent.

### 5.3 Deep-dive every authority-bearing seam

At minimum, deep dives cover:

- lifecycle states, legal transitions, invalidation, and re-entry;
- authentication, policy, human decision, authority grant, permit, effect, and
  reconciliation order;
- exact-subject and content-addressed evidence;
- transaction, outbox, concurrency, retry, idempotency, time, and fencing;
- data classification, retention, backup, restore, migration, and purge;
- dependency direction and public API stability;
- sandbox, path, process, network, secret, and extension isolation;
- degraded modes, cancellation, rollback, incident, and disaster recovery;
- observability and support;
- upstream synchronization, compatibility, and de-commercialization; and
- construction, verification, release, operation, and retirement attachment
  points.

The deep dive selects the risk-bearing parts of the **whole design**. It does
not hide the rest of the map.

### 5.4 Compare alternatives

Every alternative is evaluated against:

- correctness and exact authority;
- essential versus accidental complexity;
- information hiding and coupling/cohesion;
- testability and observability;
- reversibility and migration;
- security and blast radius;
- operational failure/recovery;
- maintainability and cognitive load;
- compatibility/upstream cost;
- delivery and verification capacity;
- total lifecycle cost; and
- explicit evidence that could falsify the choice.

The status quo is always an alternative. A familiar pattern name, book
recommendation, model consensus, or fashionable topology is not evidence that
an alternative fits Ranex.

### 5.5 Record and govern the decision

The `ArchitectureReviewPacket` freezes the exact subject. DeepSeek V4 Pro may
serve as the primary architecture specialist and HY3 as an independent
challenger only when their actual routes are qualified and recorded. Their
proposals become findings/evidence. The human architecture authority accepts,
rejects, or defers through the normal RFC/ADR and Core-SDLC controls.

## 6. File-structure rules derived from the major references

### 6.1 Organize around owned concepts

The target source tree is organized by bounded context and authority, not by
model provider, UI page, generic “manager,” or current implementation phase.
Each context has:

```text
context_name/
├── api/
│   ├── commands.py
│   ├── queries.py
│   ├── events.py
│   └── views.py
├── domain/
├── application/
│   └── ports/
└── infrastructure/  # only when the context owns an implementation detail
```

Adapters and applications remain outside domain authority. Composition code
wires implementations; it does not contain business rules.

### 6.2 Make dependencies point inward

Allowed direction:

```text
apps/adapters -> application ports/services -> domain
                         |
                         +-> typed public API of another context
```

Forbidden direction:

```text
domain -> provider SDK / UI / filesystem / network / legacy Hermes
context internals -> another context's domain internals
worker harness -> authority database
adapter -> direct state mutation
generated contract -> handwritten semantic override
```

This applies Code Complete's complexity/information-hiding guidance, Clean
Code's boundary discipline, and Pragmatic orthogonality without treating any
one object-oriented idiom as mandatory.

### 6.3 Separate construction from runtime authority

Configuration discovery, dependency assembly, migration, startup validation,
and process launch live in composition/bootstrap packages. Runtime domain
objects receive already-validated ports and immutable configuration views.
Import-time registration, environment-presence auto-selection, and hidden
global mutation are forbidden.

### 6.4 Put volatile details behind narrow ports

Provider/model routes, Hermes harnesses, tool protocols, policy engines,
workflow runtimes, sandboxes, Git hosts, messaging channels, and storage
implementations attach through owned ports. Ports describe Ranex needs rather
than mirroring vendor SDKs.

### 6.5 Keep contracts and examples generated from one semantic source

Architecture registries define identities, state, ownership, dependencies,
events, authority, lifecycle crosswalks, invalidation, and compatibility.
Schemas validate artifacts. Generated Python/TypeScript types and examples are
projections. Hand-edited duplication fails CI.

### 6.6 Mirror risk in tests

Tests are organized by what they falsify:

```text
tests/
├── unit/          # pure domain rules
├── contract/      # schemas and public APIs
├── integration/   # owned adapter/context seams
├── property/      # invariants and state machines
├── resilience/    # crash, retry, restore, reconciliation
├── security/      # denial and bypass paths
├── migration/     # old/new state and cutover
├── compatibility/ # Hermes/upstream/public behavior
└── evaluation/    # route, harness, checker, fleet effectiveness
```

Coverage locates missing evidence. It is not a release verdict, capability
score, or substitute for boundary/failure tests.

## 7. Construction and change discipline

For each bounded change:

1. Bind the accepted requirement/design/subject and allowed paths.
2. Establish a failing requirement-level, contract, property, or regression
   check where applicable.
3. Implement the smallest coherent vertical change inside the mapped
   boundary.
4. Keep domain decisions explicit and vendor/infrastructure details behind
   ports.
5. Run fast checks continuously; run risk-required integration, resilience,
   security, migration, compatibility, and evaluation checks before the
   corresponding gate.
6. Refactor only inside declared scope and only with preserved proof.
7. Record actual commands, changed files/dependencies, evidence, unknowns, and
   deviations.
8. Obtain independent review and deterministic gate evidence.
9. Land through human-controlled authority.
10. Verify the landed subject, operate it, and review outcome.

A vertical tracer is a production-shaped route through already-mapped
architecture. It is **not** an MVP, prototype, temporary architecture, excuse
for missing owners, or permission to leave interfaces undefined. Disposable
experiments are quarantined research artifacts and do not silently become the
product.

## 8. Verification strategy

The combined major-reference position is:

- acceptance examples clarify behavior but do not replace requirements;
- unit tests prove local rules but not integration or operation;
- component/contract tests prove stable boundaries;
- integration tests prove actual adapter interactions;
- property/state-machine tests challenge invariants and transitions;
- system/end-to-end tests prove representative journeys;
- security tests attempt denied routes and bypasses;
- resilience tests inject crash, timeout, replay, stale lease, partial
  external effect, restore, and reconciliation conditions;
- compatibility tests bind inherited/upstream behavior and deprecation;
- exploratory evaluation finds classes of failure not captured by known
  assertions;
- operational validation proves health, support, recovery, and user outcome;
  and
- no worker's own test or favorable model review authorizes its change.

Fixed test pyramids, universal coverage percentages, or “QA should find
nothing” are rejected. Independent findings are useful system evidence, not
professional shame.

## 9. Professional work, estimation, and commitments

The Clean Coder is applied through the Core SDLC, not as personal mythology:

- distinguish an estimate distribution from an accepted commitment;
- commit only to actions within controlled scope and named dependencies;
- disclose uncertainty, risk, and lateness early with evidence;
- never trade away required verification to preserve a date;
- ask for and offer help without transferring accountability invisibly;
- keep work at a sustainable pace;
- preserve time for competence, mentoring, and process improvement; and
- treat Definition of Done as an organizational evidence contract, not a
  worker's private assertion.

No fixed workweek, overtime threshold, team size, coverage target, staffing
ratio, apprenticeship hierarchy, or development technique becomes mandatory
solely because a book recommends it.

## 10. Book-specific guardrails

| Reference proposition | Ranex disposition |
|---|---|
| Design is iterative/emergent | Accepted inside a stable full-map boundary; material discoveries re-enter design/change control |
| Manage complexity with decomposition and information hiding | Accepted and made enforceable through contexts, ports, ownership, dependency tests, and narrow public APIs |
| Code is the only truth | Rejected; runtime behavior matters, but requirements, decisions, schemas, evidence, release records, and operational facts have distinct authority |
| Keep design simple | Accepted as minimizing accidental complexity, never as omitting essential authority, failure, security, or lifecycle behavior |
| Tracer bullets | Accepted as reversible vertical delivery routes through the full architecture; never relabeled MVP/prototype scope |
| DRY | Accepted for authoritative knowledge and needless duplication; rejected when it produces a shared database/god service or erases bounded-context ownership |
| Automate everything repeatable | Accepted where automation is observable, qualified, reversible, and governed; automation cannot self-approve |
| TDD or one testing style defines professionalism | Rejected; test technique is chosen by risk and subject, while required evidence remains mandatory |
| Web-scale cache/queue/shard patterns | Catalogue only; require measured need, one-host product compatibility, failure semantics, operations, and accepted ADR |
| Interview-style four-step design | Adapted into scope, complete high-level map, risk deep dives, and evidence-bound reconciliation; time-box advice is not policy |
| Fixed coverage/test-pyramid/team/velocity numbers | Rejected as universal gates; calibrate locally without weakening mandatory controls |
| Individual heroics under pressure | Rejected; transparent system-level planning, assistance, sustainable pace, and evidence-based recommitment govern |

## 11. Fog closed by this map

| Previously ambiguous area | Closed position |
|---|---|
| Full architecture versus iterative design | The destination is fully mapped; details evolve through governed feedback and ADRs |
| Ground zero versus fork | New authority/domain/application core, built through a strangler inside a provenance-proven Hermes-derived fork |
| Tracer versus MVP/prototype | A tracer is a narrow route and proof instrument; it does not define or shrink the target |
| Modular monolith versus distributed system | Product deployment is one-host modular monolith; worker coordination and external effects still require distributed-systems controls |
| File structure | Context/authority first, then API/domain/application/ports/adapters; composition and legacy boundaries are explicit |
| Provider/model placement | Replaceable adapter/route behind qualified ports; never a domain or authority owner |
| Review and acceptance | Observation, deterministic evidence/gate, accountable human decision, grant, permit, and effect are separate |
| Testing depth | Risk-based layered falsification, not unit-test or coverage monoculture |
| Estimation and promises | Estimates express uncertainty; commitments require accountable scope/dependency/capacity decisions |
| Operations | Health, SLO/support, incident, recovery, backup/restore, reconciliation, maintenance, and retirement are designed before release |
| Desktop | Electron desktop is excluded; CLI, TUI, loopback web, GitHub edge, and text-phone surfaces attach to shared application APIs |
| AI agents | Workers execute bounded roles; the human-established SDLC remains the method and authority frame |

## 12. Acceptance tests

This reference map is not complete merely because the books were listed. It is
falsified if:

1. a major architecture decision cannot trace to an owned requirement,
   applicable lifecycle/control, alternatives, and falsification evidence;
2. an architecture review omits owner, state, data, effect, API, file,
   failure, recovery, or lifecycle consequences;
3. an implementation route is used to justify an unmapped target area;
4. a book heuristic overrides an accepted control without an ADR;
5. AI research or model consensus changes human decision rights;
6. a vendor/web-scale pattern enters the target without measured need and
   operational/failure analysis;
7. a test percentage, model score, or process average hides a mandatory
   failure;
8. code bypasses a context public API, authority cell, `CapabilityBus`, or
   owned port;
9. a PDF/Markdown pair is counted as independent corroboration;
10. any saved reference remains absent from the frozen manifest and licensing
    classification;
11. a local full-text reference is published without a documented rights
    basis; or
12. a changed reference does not trigger impact review of the rules it
    supports.

## 13. Current standing

The reference application map is a complete **practice attachment map**. It
does not prove that Ranex implements or follows the practices. Runtime adoption
requires machine contracts, representative normal and rejection tracers,
independent verification, operations evidence, capability assessment, and the
human decisions defined by the Core SDLC.

The correct status is:

> **All frozen major references mapped to named engineering responsibilities;
> rights, fork preflight, executable contracts, and runtime conformance remain
> separate blocking evidence.**
