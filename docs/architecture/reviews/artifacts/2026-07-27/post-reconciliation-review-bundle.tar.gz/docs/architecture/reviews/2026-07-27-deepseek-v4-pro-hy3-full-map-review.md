# DeepSeek V4 Pro and HY3 Full-Map Architecture Reconciliation

| Field | Value |
|---|---|
| Review ID | `REVIEW-ARCH-RANEX-001` |
| Version | `1.1.0` |
| Date | 2026-07-27 |
| Status | Advisory architecture evidence |
| Ranex HEAD at source capture | `fee61eb61d8f2df2f28adbe3a59cf8c2340ab5f4` |
| Historical OpenCode version | `1.18.7` |
| Historical execution mode | `plan`, read-only, `--pure` |
| Primary collaborator | `deepseek/deepseek-v4-pro`, variant `high` |
| Independent challenger | `openrouter/tencent/hy3`, variant `high` |
| Independence standing | Historical passes were procedurally separate but not mechanically attested; advisory only |
| Repository mutations by reviewers | None |
| Decision authority | Human owner |

## 1. Purpose

The owner requested architecture and file-structure collaboration with HY3 and,
especially, DeepSeek V4 Pro. Two parallel review passes were performed:

1. a ground-zero architecture and file-structure pass; and
2. a corrected full-map completeness pass after the owner rejected MVP/v1-only
   documentation.

DeepSeek V4 Pro acted as the primary specialist. HY3 received the same
historical research corpus independently and challenged boundaries, authority,
completeness, and testing. A later direct-API, exact-route round retained raw
responses and provider metadata. The architecture was then synthesized against
local research and repository evidence by the human-governed documentation
process; neither model became a decision authority.

## 2. Frozen evidence corpus

The historical initial corpus consisted of the following five files—the
research files present and selected at that capture. Later research and visual
artifacts are not retroactively claimed as inputs to these first two passes.

| File | Lines | SHA-256 |
|---|---:|---|
| `cookbook-alignment-research-2026-07-27.md` | 1,496 | `344c14f6e5a475af2eebdd5ff444079188b5bf78c44c65fafbada662d352b4c7` |
| `gemini-research.md` | 302 | `db92a0c3dd9b51d3fbaa5b5072c00e79b81f6fcb853e552c02257eee8ec82a8a` |
| `hermes-core-architecture-hy3-review-2026-07-27.md` | 237 | `7d8e90898b0506a3ea32f6e4af3ed43eb34ef2049c129126dbdf9b4c3fccc0e7` |
| `hermes-core-architecture-research-2026-07-27.md` | 2,450 | `4c3e642ad245a62cdea14cdd508e5ec4a30314781127efa46ba6c06bafe5d29b` |
| `ocask-alignment-research-2026-07-27.md` | 2,779 | `f3a57e48b3081203922210081bfb22e19b0feeaabf5fea8ca8aa7a82d680e41f` |

Total: 7,264 lines.

`RANEX_IMPLEMENTATION_GUIDE.md` and the repository structure were also inspected
for context. The reviewers were not asked to modify files.

The OCAsk digest in this table is the historical pre-format-normalization
subject. The reduced direct-review manifest later bound the same path at
`1856b91765bcb7b95533738ff37ba13c7b04d8af447a16a728c9b1e96a0fad43`.
They are different revisions, not two names for one byte sequence. The later
manifest is retained at
[`source-manifest.sha256`](./artifacts/2026-07-27/source-manifest.sha256).

## 3. Review prompts and roles

### 3.1 DeepSeek V4 Pro — primary architecture collaborator

The first pass requested:

- system context and modular-monolith bounded contexts;
- domain/application/ports/adapters boundaries;
- deterministic workflow and state authority;
- evidence/gate and capability/sandbox semantics;
- model/provider adapter boundary;
- exact repository/package/file tree;
- dependency/public-API rules;
- data and transaction ownership;
- event/outbox strategy;
- configuration, schema, testing, observability, migration, and cutover;
- AI-agent development lifecycle; and
- challenges to potential god objects.

The corrected pass explicitly required the entire target-system map, including
every final attachment point for inactive or later-implemented capability zones.
It also fixed these owner inputs:

- Ranex remains a fork of `nousresearch/hermes-agent`;
- ground zero is a dependency-clean core inside the fork;
- the desktop app is excluded;
- CLI, TUI, local web, phone, and GitHub surfaces remain mapped; and
- implementation routes cannot define the map's extent.

### 3.2 HY3 — independent challenger

The first pass challenged:

- hidden coupling and god packages;
- authority bypass;
- workflow/replay correctness;
- split sources of truth;
- evidence versus verdict;
- provider identity;
- untrusted model output;
- process isolation;
- migration hazards; and
- enforceable source modularity.

The corrected pass audited the architecture for unseen territory and demanded
owners, lifecycles, trust/security boundaries, and source locations for every
capability zone.

## 4. DeepSeek V4 Pro contributions adopted

DeepSeek V4 Pro materially shaped:

- the product inversion from an agent-centered runtime to governed execution;
- the trust-tier model;
- the explicit domain/application/port/adapter split;
- the first-party module descriptor and lifecycle;
- the detailed repository and test tree;
- route-lock identity for provider/model/transport/tool/parser tuples;
- two distinct analytical transports: native tool-free and tool-bearing
  sandboxed;
- deterministic workflow, effect, permit, and policy-freshness semantics;
- explicit context/instruction/packet and skills/memory boundaries;
- de-commercialization and upstream compatibility treatment;
- full target surface decisions, including removal of desktop;
- the principle that delivery phases are routes through the full map; and
- explicit product exclusions rather than blank deferred territory.

## 5. HY3 corrections adopted

HY3 materially strengthened:

1. **Authority atomicity.** Run state, exact gate bindings, permit/decision
   consumption, journal event, and effect intent must share one strong
   transaction.
2. **Application decomposition.** “Control plane” is a trust layer, not one god
   package. Application services remain beside their owning context.
3. **`ExecutionContext` containment.** The full envelope is forbidden in domain
   method signatures; contexts receive minimal immutable subject views.
4. **Transitional honesty.** Inherited Hermes/Codex/Claude/OpenCode loops have
   only activity/OS mediation until real tool paths are rewired and tested.
5. **Real bypass matrix.** Sequential, parallel, terminal, file, browser, MCP,
   app-server, subagent, background, plugin, process, and network routes need
   real denial tests.
6. **Evidence/verdict separation.** Model `ReviewObservation` and accepted
   `GateOutcome` are distinct schemas and flows; a model-only observation cannot
   create `PASS`.
7. **Split-source reconciliation.** Hermes session state and Kanban are
   projections/private module state; divergence is typed and blocks instead of
   creating another authority.
8. **Packet determinism.** Digests bind resolved source/retrieval revisions;
   stochastic retrieval is a recorded activity.
9. **Provider identity.** Any route-lock field change forces probation.
10. **Knowledge quarantine.** Memory, skills, and learning need a mapped,
    project-scoped quarantine/sanitization/approval boundary.
11. **Missing full-map owners.** Identity/access/secrets, artifacts,
    operations, backup/restore, release/update, upstream sync, migration, and
    external extensions needed explicit contexts.
12. **Anti-recontamination.** De-commercialization and architecture gates must
    run on upstream-sync candidates as well as releases.

## 6. Reconciled decisions

| Question | DeepSeek direction | HY3 challenge | Reconciled architecture |
|---|---|---|---|
| Four core contexts or one? | Four semantic core contexts | Separate persistence can split authority | Keep semantic contexts, but place run/gate/permit/effect mutation in one `governed_execution` authority cell and transaction |
| Application control location | Cross-context process manager | New god-object risk | Per-context application services; one orchestration-only process manager; one narrow PEP/UoW |
| Legacy layout | Compatibility facade | Full fork co-location was not drawn | Transitional inherited root plus sole facade import; target frozen subset under `legacy/hermes` after parity |
| Review authority | Models provide structured reviews | Evidence may collapse into verdict | Separate request, attempt, observation, checker result, gate outcome, human decision, and permit |
| Desktop | Generic delivery module | Must be explicit | No desktop package; local web provides visual UX |
| Phone | Text-phone adapter | Transport/auth unclear | Channel-neutral delivery port, Telegram first adapter, shared decision/auth contract |
| Deferred areas | Attachment points listed selectively | Full-map omissions remain | Every capability receives a final owner and attachment point or explicit exclusion |
| State/event design | Replayable journal and current state | Which one wins on divergence? | Current row is operational; journal is replay oracle; mismatch is corruption and blocks |
| Workflow engine | Local runner first | Home-grown durability is R&D | Runtime port is permanent; local runner must pass the same matrix as any mature alternative |
| Upstream fork | Strangler and compatibility | Upstream may reintroduce removed surfaces | Dedicated governed upstream-sync context and anti-recontamination gate |

## 7. Full-map omissions closed

The corrected architecture adds named boundaries for:

- identity, authentication, remote decisions, data classification, and secrets;
- content-addressed artifacts, access, retention, hold, expiry, and purge;
- operations, health, incidents, reconciliation, and telemetry;
- encrypted backup/restore and external-state reconciliation;
- explicit install, update, release, rollback, and SBOM handling;
- governed upstream fetch/classification/challenge/port/verification;
- schema, module, workflow, and legacy migration coordination;
- quarantined knowledge/skills/memory/learning;
- separate route qualification and whole-system effectiveness evaluation;
- external extension lifecycle and out-of-process protocol;
- tool/MCP/search/browser attachment families;
- full delivery surfaces and shared human-decision contract;
- compliance/provenance and de-commercialization ownership; and
- transitional and target physical repository layouts.

## 8. Limitations

1. The model outputs are advisory and were not runtime acceptance tests.
2. The historical reviewers read the five-file corpus named in section 2.
   Later visual, SDLC, Kimi, book, and other research is not retroactively
   claimed as an input to those passes. No review performed a fresh exhaustive
   audit of every upstream Hermes source file.
3. The current Ranex repository still contains documentation rather than the
   target runtime.
4. The architecture remains unvalidated until its P0 tests pass.
5. Provider behavior and model identities may change; the recorded routes apply
   to this review date and access path.
6. Raw outputs from the first historical OpenCode passes were not retained as
   canonical artifacts. Raw response bytes and provider metadata from the
   later direct-API review were retained, but provider metadata remains
   provider-supplied evidence rather than an independently witnessed billing or
   identity attestation.
7. No credential value was printed or copied into the repository.

## 9. Outcome

The collaboration produced:

- a complete target-system architecture rather than a narrow v1/MVP map;
- a concrete end-state repository and package structure;
- a separate AI-agent development lifecycle;
- a source-of-truth and decision policy; and
- explicit validation gates that must pass before the architecture is called
  runtime-validated.

The correct current status is:

> **Complete target map; conditionally accepted architecture; no runtime proof
> yet.**

## 10. Retained direct-API pre-reconciliation review

A later review used the exact requested routes directly and retained the
provider responses byte-for-byte. It reviewed the reduced bundle frozen in
[`source-manifest.sha256`](./artifacts/2026-07-27/source-manifest.sha256) with
[`final-full-map-review-prompt.md`](./artifacts/2026-07-27/final-full-map-review-prompt.md).
That bundle included the then-current normative architecture documents and nine
top-level research/visual artifacts. It did not include the subsequently
arriving Kimi corpus, book corpus, new fleet specification, or the complete
template set, so it is a pre-reconciliation review rather than the final exact
subject.

| Reviewer call | Actual route/model | Response ID | UTC interval | Response SHA-256 |
|---|---|---|---|---|
| DeepSeek part 1 | `deepseek` / `deepseek-v4-pro` | `3336015f-da40-4011-ba4a-6dba62e47f9c` | `13:13:26.873Z`–`13:15:16.562Z` | `2349bbe616ee574b6b90b3451addcaf59c11fa252526c4a0ea77af067b12f150` |
| DeepSeek continuation | `deepseek` / `deepseek-v4-pro` | `151058f3-ab09-48bf-9789-7e1e2474edfb` | `13:23:29.407Z`–`13:24:09.494Z` | `7e8479853baa5d8ae3e921a31e04516f262427d88ca16c2acb76f28f5268ba0f` |
| HY3 independent challenge | `openrouter` / `tencent/hy3` | `gen-1785158547-NJy3i1xLtrxTsafCulgG` | `13:22:27.018Z`–`13:24:22.906Z` | `1029d1b98ecf3e1b7c9fa654814f4716dcdf0d3c174d5e520b728db093583481` |

DeepSeek part 1 ended mid-section because the response reached its output
limit. The continuation was a second authenticated request bound to the first
response digest; it is not represented as one atomic provider response. The
first DeepSeek request used bundle digest
`8ffa853f1e8499387fd154dc4bfc4cf51e3e24e5f862b6857b254646363ac066`.
The reconstructed continuation and independent HY3 requests used bundle digest
`3d0ec7bbb66ac23c1aa882611017d15ab7893c767266bb03ae6083f52e192b98`.
The frozen prompt digest was
`e20b481c027105c2b16f66299664a854d4db2aabba6f64851b4358f1cad2eab4`.

Retained evidence:

- [DeepSeek V4 Pro part 1](./artifacts/2026-07-27/deepseek-v4-pro-final-review-part-1.md)
  and [metadata](./artifacts/2026-07-27/deepseek-v4-pro-final-review-part-1.metadata.json);
- [DeepSeek V4 Pro continuation](./artifacts/2026-07-27/deepseek-v4-pro-final-review-part-2.md)
  and [metadata](./artifacts/2026-07-27/deepseek-v4-pro-final-review-part-2.metadata.json); and
- [HY3 independent challenge](./artifacts/2026-07-27/hy3-final-review.md)
  and [metadata](./artifacts/2026-07-27/hy3-final-review.metadata.json).

DeepSeek found the map acceptable for formal contracting with no P0 finding.
HY3 returned `CHANGES_REQUIRED`, principally because the repository still
lacked fork-lineage proof and executable contracts. That is a valid
implementation blocker, but not permission to collapse the documented map.

## 11. Direct-review finding reconciliation

| Finding | Disposition and exact correction |
|---|---|
| Signed-maintenance key ownership was ambiguous | Accepted. `release_management` owns signing policy, allowed key IDs, manifests, and signed records; `identity_access` and its secret backend custody raw private material; bootstrap pins public trust roots; the human release authority owns ceremony, rotation, and revocation. No application service stores raw keys. |
| Architecture review did not bind the exact architecture subject | Accepted. `ArchitectureSubjectV1`, exact architecture-document and manifest digests, `CoreSDLCTrace`, and corresponding architecture packet/proposal/reconciliation fields were added to the artifact contract and templates. |
| Fork preflight was prose-only | Accepted. `SDLC-FORK-000` is registered in the control catalog with required evidence and is blocking before any runtime implementation commit enters the product branch. The actual GitHub network-fork fact may remain `false`; it is not fabricated to imply Git ancestry. |
| Sixteen work-item states were not listed clearly enough | Accepted. The Core SDLC lists the normal thirteen-state path plus `BLOCKED`, `CANCELLED`, and `ROLLED_BACK`; the semantic HTML contains sixteen state cards. |
| Raw direct-review outputs were absent | Accepted for the later round. Exact response bytes, digests, request/route metadata, timestamps, and usage are retained above. Historical output absence remains disclosed. |
| Visual-review hashes were stale | Accepted. The visual review retains historical hashes as history and adds a current exact-subject supersession section. |
| Real-harness bypass tests lacked a file home | Accepted. The target tree includes `tests/security/bypass_matrix/` and per-harness, helper, subprocess, filesystem, process, network, plugin, MCP, subagent, background, and alternate-tool denial coverage. |
| `process_assurance` lacked an explicit adapter | Accepted. The target tree and responsibility catalog include the `process_assurance` adapter package and measurement/conformance ports. |
| Templates and machine schemas are not runtime-implemented | Confirmed, not hidden. Templates are provisional examples until `AI-G2`; future `architecture/contracts/` schemas and registries must pass contract generation and validation before the first governed runtime tracer. |
| Fork ancestry remains unproven | Confirmed, not waived. The map is conditionally accepted while `SDLC-FORK-000 = PENDING`; runtime implementation is blocked. |

The Kimi addendum arrived after this round and was separately audited in
[Kimi Agent-Fleet Research Reconciliation](./2026-07-27-kimi-agent-fleet-research-reconciliation.md).
A final post-reconciliation exact-subject review must therefore use a new
manifest and cannot inherit either verdict automatically.
